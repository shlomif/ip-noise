package IP::Noise;

sub get_max_id_string_len
{
    return 79;
}

1;
