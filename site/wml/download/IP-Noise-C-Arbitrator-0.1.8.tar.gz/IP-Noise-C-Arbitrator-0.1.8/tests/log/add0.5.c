double add_0_5(double a)
{
	return a+0.5;
}
